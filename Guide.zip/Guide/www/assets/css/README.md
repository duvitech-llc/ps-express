MWF Version 1.8
---------------

https://assets.onestore.ms/cdnfiles/external/mwf/long/v1/v1.8.2/css/mwf-west-european-default.css